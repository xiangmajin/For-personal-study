package com.xidian.ui;


import javax.sound.sampled.*;
import javax.swing.*;
import javax.swing.border.BevelBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.Random;

public class GameJFrame extends JFrame implements KeyListener , ActionListener {
    //记录图片位置
    String path1="image\\";
    String path2="sound\\";

    //创建栏目下的多个菜单
    JMenuItem restartGame = new JMenuItem("新游戏");
    JMenuItem reLoginItem = new JMenuItem("重新登录");
    JMenuItem closeItem = new JMenuItem("关闭页面");
    JMenuItem qq = new JMenuItem("的女朋友");
    //记录数据
    Random random = new Random();
    int t=random.nextInt(2);;
    int x=0,y=0;
    int step=0;
    int [][]arr1 = new int[4][4];
    int [][]win={
            {0,1,2,3},
            {4,5,6,7},
            {8,9,10,11},
            {12,13,14,15},
    };






    public GameJFrame() {

        initGameJFrame();
        initMenu();
        initData();
        initimage();
        this.setVisible(true);
    }
    //声音加载
    private void playSound1() {
        try {
            // 替换为你的音效文件路径
            File soundFile = new File("D:\\desktop\\java-code\\jigsaw_puzzle\\sound\\move\\move2.wav");
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(soundFile);
            Clip clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            clip.start();
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            e.printStackTrace();
        }
    }
    private void playSound2() {
        try {
            // 替换为你的音效文件路径
            File soundFile = new File("D:\\desktop\\java-code\\jigsaw_puzzle\\sound\\win_sound\\2025-02-24 recording bilibili-com.wav");
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(soundFile);
            Clip clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            clip.start();
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            e.printStackTrace();
        }
    }
    //(打乱)初始化数据
    private void initData() {
        int index;
        int temp;
        int[] arr2={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
        for (int i = 0; i < 16; i++) {
            Random r = new Random();
            index = r.nextInt(arr2.length);
            temp=arr2[i];
            arr2[i]=arr2[index];
            arr2[index]=temp;
        }
        for (int i = 0; i <16; i++) {
            if(arr2[i]==15){
                x=i/4;
                y=i%4;
                arr1[i/4][i%4]=arr2[i];
            }else{
                arr1[i/4][i%4]=arr2[i];
            }
        }

    }
    //图片加载
    private void initimage() {
        //删除已经出现的图片
        this.getContentPane().removeAll();

        int number = 0;
        if(isWin()){
            playSound2();
            //创建一个图片对象
            ImageIcon backeground = new ImageIcon(path1+"win\\win1.jpg" );
            //创建一个面板对象
            JLabel jPanel2 = new JLabel(backeground);
            //设置图片的位置
            jPanel2.setBounds(-25, -100, 950, 1000);
            this.getContentPane().add(jPanel2);

        }
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                number=arr1[i][j];
                //创建一个图片对象
                ImageIcon imageIcon = new ImageIcon(path1+"image\\image"+t+"\\"+number+".png");
                //创建一个面板对象
                JLabel jPanel = new JLabel(imageIcon);
                //设置图片的位置
                jPanel.setBounds(150 * j +150, 150 * i +100, 150, 150);
                jPanel.setBorder(new BevelBorder(0));
                this.add(jPanel);

            }

        }

        JLabel stepCount=new JLabel("步数："+step);
        stepCount.setBounds(50,50,100,50);
        this.getContentPane().add(stepCount);
        //创建一个图片对象
        ImageIcon backeground = new ImageIcon(path1+"nailong\\nailong2.jpg" );
        //创建一个面板对象
        JLabel jPanel2 = new JLabel(backeground);
        //设置图片的位置
        jPanel2.setBounds(-50, -50, 950, 1000);
        this.getContentPane().add(jPanel2);
        //刷新
        this.getContentPane().repaint();


    }
    //窗口设置
    private void initGameJFrame() {
        this.setSize(900, 800);
        this.setTitle("动漫研拼图小游戏 v1.0"); //设置标题
        this.setLocationRelativeTo(null); //居中显示
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); //设置关闭模式
        this.setLayout(null);
    }
    //菜单
    private void initMenu() {
        //创建整个菜单对象
        JMenuBar jMenuBar = new JMenuBar();
        //创建两个栏目
        JMenu functionMenu = new JMenu("功能");
        JMenu aboutMenu = new JMenu("关于我");

        //将菜单添加到栏目
        functionMenu.add(restartGame);
        functionMenu.add(reLoginItem);
        functionMenu.add(closeItem);
        aboutMenu.add(qq);
        //给条目绑定事件
        restartGame.addActionListener(this);
        reLoginItem.addActionListener(this);
        closeItem.addActionListener(this);
        qq.addActionListener(this);
        //将栏目添加到菜单
        jMenuBar.add(functionMenu);
        jMenuBar.add(aboutMenu);
        //将菜单设置到窗口
        this.setJMenuBar(jMenuBar);
        //给菜单项添加键盘监听事件
        this.addKeyListener(this);
    }
    //判断是否胜利
    public boolean isWin(){
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                if(arr1[i][j]!=win[i][j]){
                    return false;
                }
            }
        }
        return true;

    }






    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

        //显示完整图片
        int code=e.getKeyCode();
        if(code==81){
            this.getContentPane().removeAll();
            JLabel all=new JLabel(new ImageIcon(path1+"image\\image"+t+"\\16.jpg"));
            all.setBounds(-20, -100, 950, 1000);
            this.getContentPane().add(all);
            ImageIcon backeground = new ImageIcon(path1+"nailong\\nailong2.jpg" +
                    "");
            //创建一个面板对象
            JLabel jPanel2 = new JLabel(backeground);
            //设置图片的位置
            jPanel2.setBounds(-50, -50, 950, 1000);
            this.getContentPane().add(jPanel2);
            //刷新
            this.getContentPane().repaint();
        }

    }

    @Override
    public void keyReleased(KeyEvent e) {
        if(isWin()){
            return;
        }
        int code=e.getKeyCode();
        System.out.println(code);
        if(code==37){
            //向左移动
            if (y != 3) { // 检查边界
                arr1[x][y] = arr1[x][y+1];
                arr1[x][y+1] = 15;
                y++;
                step++;
                // 重新初始化图片
                initimage();
                playSound1();
            }else{
                return;
            }



        }else if(code==38){
            //向上移动
            if (x !=3) { // 检查边界
                arr1[x][y] = arr1[x +1][y];
                arr1[x +1][y] = 15;
                x++;
                step++;
                // 重新初始化图片
                initimage();
                playSound1();
            }else{
                return;
            }

        }else if(code==39){
            //向右移动
            if (y != 0) { // 检查边界
                arr1[x][y] = arr1[x][y-1];
                arr1[x][y-1] = 15;
                y--;
                step++;
                // 重新初始化图片
                initimage();
                playSound1();
            }else{
                return;
            }
        }else if(code==40){
            //向下移动
            if (x != 0) { // 检查边界
                arr1[x][y] = arr1[x -1][y];
                arr1[x -1][y] = 15;
                x--;
                step++;
                // 重新初始化图片
                initimage();
                playSound1();
            }else{
                return;
            }
        }
        else if(code==81){
            initimage();
        }
        else if(code==87){
            arr1 =new int[][]{
                    {0,1,2,3},
                    {4,5,6,7},
                    {8,9,10,11},
                    {12,13,14,15}
            };
            x=y=3;
            initimage();
        }

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object obj=e.getSource();
        if(obj==restartGame){
            Random random = new Random();
            this.t=random.nextInt(2);;
            step=0;
            initData();
            initimage();
        }else if(obj==reLoginItem){
            this.setVisible(false);
            new LoginJFrame();
        }else if(obj==closeItem){
                System.exit(0);
        }else if(obj==qq){
            JDialog jDialog=new JDialog();
            JLabel jLabel=new JLabel(new ImageIcon("image\\sihuo\\lover.jpg"));
            jLabel.setBounds(0, 0,258 , 258);
            jDialog.getContentPane().add(jLabel);
            jDialog.setSize(800, 800);
            jDialog.setAlwaysOnTop(true);
            jDialog.setLocationRelativeTo(null);
            jDialog.setModal(true);
            jDialog.setVisible(true);
        }
    }
}
