package com.xidian.ui;

import javax.swing.*;
import java.awt.event.*;

public class LoginJFrame extends JFrame{

    public LoginJFrame() {
        initLoginJFrame();
        startGame();
        backGround();// 调用 startGame 方法添加组件
        this.setVisible(true);
    }


    private void initLoginJFrame() {
        this.setSize(600, 600);
        this.setTitle("动漫研拼图小游戏 v1.0"); // 设置标题
        this.setLocationRelativeTo(null); // 居中显示
        this.setDefaultCloseOperation(2); // 设置关闭模式
        this.setLayout(null); // 设置布局管理器为 null，使用绝对布局
    }


    private void startGame() {
        JLabel stepCount = new JLabel("点击开始游戏");
        stepCount.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // 处理 JLabel 被点击的事件
                System.out.println("JLabel 被点击了，开始游戏！");
                GameJFrame gameJFrame = new GameJFrame();
                dispose();
            }
        });
        stepCount.setBounds(250, 250, 100, 50);
        this.getContentPane().add(stepCount);
    }

    private void backGround() {
        ImageIcon backeground = new ImageIcon("D:\\desktop\\java-code\\jigsaw_puzzle\\image\\nailong\\nailong2.jpg");
        //创建一个面板对象
        JLabel jPanel2 = new JLabel(backeground);
        //设置图片的位置
        jPanel2.setBounds(-250, -200, 950, 1000);
        this.getContentPane().add(jPanel2);
        //刷新
        this.getContentPane().repaint();
    }
}