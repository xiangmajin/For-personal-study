import com.xidian.ui.GameJFrame;
import com.xidian.ui.LoginJFrame;

public class APP {
    public static void main(String[] args) {

        LoginJFrame loginJFrame = new LoginJFrame();
        String workingDir = System.getProperty("user.dir");
        System.out.println("当前工作目录: " + workingDir);

    }
}
